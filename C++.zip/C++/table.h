#pragma once 

extern const int ins[][30];
